#!usr/bin/env python3

# Created by Gabriel A
# Created on Nov 2020
# This program is for number guessing


import number


def main():
    # input
    guessed = int(input("Pick a number between 0-9: "))

    # process
    if guessed == number.NUMBER:
        # output
        print("Congratulations! You picked the right number!")


if __name__ == "__main__":
    main()
