#!usr/bin/env python3

# Created by Gabriel A
# Created on Nov 2020
# This is a constant for num.py


NUMBER = 7
